## Digital Wolves Games presents...

Tower Defender:

Introduction:

Age Of Empires 2: Defenders is a game for the Project 2 subject on the Design and Development of Videogames degree
at Centre de la Imatge i la Tecnologia Multimedia (CITM), Terrassa. Our aim will be to create a Tower Defense with some mechanics,
units, buildings and art from Age of Empires II: The Age of Kings, developed by Ensemble Studios.

About final Game:

You are the comander of a small village and you will need to defend to the diferents civilizations.
You will need to survive the maximum number of waves to repel the atack. Each wave will encrease the difficulty of the enemies waves.
You can build towers and training camps to protect the village. You can put the towers on the green areas. Also we can upgrade with the resouces
and do more efective the stadistics of towers.
The player will win once the time counter is over (30 minutes) and will lose if the enemy destroys the wall to the city.

Resaouces: 

You will get an area to collect resouces. It serves to upgrade and build the towers and each upgrades. You can upgrade the resouces to collect faster.
But you will need to do a good managment with resouces.


Controls:

The game controles are based in a mouse and keyboard. While the keyboard can be used for “hot-keys” the mouse is used for most of the game’s control:
 - left click: select units or buildings and interact with ui (mainlly click buttons)
 - left click and drag: grup selection of units and multi wall consturction.
 - right click: is used to move selected units, chose targets and to change spawn destination of buildings that produce units.
 - Alternate through towers (Q)
 - Training Camp (W)
 - University (E)
 - Mill (A)
 - Lumber Camp (S)
 - Mining Camp (D)


Trophies:

In order to make the player play more than once and make them feel that they are getting better and better in the game we will add some trophies to collect:

 - Win the game once.
 - Gate untouched.
 - Completed wave 30.
 - Completed wave 50.
 - Complete all the investigations in one game.
 - Win the game without completing any investigation.
 - Get 50.000 gold in one game.

God Mode:

With number 1 we can build a tower wherever we like!
With "B" you can do "fade to black".


What we cand do now?

- You can move the units alone or en group, build 1 tower with the number 1 and move the camera with the directional arrows.
- Also we can press the buttons of the HUD and spawn the tower, and two diferents units with left click on a walkable tiled.
- One of the units are the villain and will fight with allies


Team members:

| Role         |     Name      |           Github             |
|:------------:|:-------------:|:----------------------------:|
| Team Leader  | Marc Latorre  | https://github.com/marclafr  |
| Code         | Dani Lopez    | https://github.com/Danny0ner |
| Design       | José Rodriguez| https://github.com/joserm45  |
| Art/Audio    | Pau Serra     | https://github.com/pau5erra  |
| UI           | Julià Mauri   | https://github.com/juliamauri|
|Management    | Martí Majó    | https://github.com/martimyc  |
|QA            | Marc Samper   |https://github.com/marcsamper |
