#ifndef _TASK
#define _TASK


class Task
{
private:	
	char* name;

public:
	virtual bool Execute();

};

#endif